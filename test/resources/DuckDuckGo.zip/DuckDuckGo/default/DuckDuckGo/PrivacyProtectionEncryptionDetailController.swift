//
//  PrivacyProtectionEncryptionDetailController.swift
//  DuckDuckGo
//
//  Copyright © 2017 DuckDuckGo. All rights reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//  http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

import UIKit
import Core

class PrivacyProtectionEncryptionDetailController: UIViewController {

    struct Section {
        var name: String
        var rows: [Row]
    }

    struct Row {
        var name: String
        var value: String
    }

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var iconImage: UIImageView!
    @IBOutlet weak var headerInfoLabel: UILabel!
    @IBOutlet weak var domainLabel: UILabel!
    @IBOutlet weak var encryptedLabel: UILabel!
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var backButton: UIButton!

    private weak var siteRating: SiteRating!

    private let serverTrustCache = ServerTrustCache.shared
    private var sections = [Section]()
 
    override func viewDidLoad() {

        Pixel.fire(pixel: .privacyDashboardEncryption)
        
        initTableView()
        initHttpsStatus()
        initDomain()
        initBackButton()
        beginCertificateInfoExtraction()

    }

    @IBAction func onBack() {
        navigationController?.popViewController(animated: true)
    }

    private func initTableView() {
        tableView.delegate = self
        tableView.dataSource = self
    }

    private func initDomain() {
        domainLabel.text = siteRating.domain
    }

    private func initBackButton() {
        backButton.isHidden = !isPad
    }

    private func initHttpsStatus() {
        headerInfoLabel.setAttributedTextString(UserText.ppEncryptionHeaderInfo)

        var message: String!

        encryptedLabel.text = siteRating.encryptedConnectionText().uppercased()
        switch siteRating.encryptionType {

        case .encrypted:
            iconImage.image = #imageLiteral(resourceName: "PP Hero Connection On")
            message = UserText.ppEncryptionStandardMessage

        case .mixed:
            iconImage.image = #imageLiteral(resourceName: "PP Hero Connection Off")
            message = UserText.ppEncryptionMixedMessage

        case .forced:
            iconImage.image = #imageLiteral(resourceName: "PP Hero Connection On")
            message = UserText.ppEncryptionForcedMessage

        default: // .unencrypted
            iconImage.image = #imageLiteral(resourceName: "PP Hero Connection Bad")
            message = UserText.ppEncryptionStandardMessage
        }

        let attributes = messageLabel.attributedText?.attributes(at: 0, effectiveRange: nil)
        messageLabel.attributedText = NSAttributedString(string: message, attributes: attributes)

    }

    private func beginCertificateInfoExtraction() {
        guard siteRating.https else { return }
        guard let serverTrust = serverTrustCache.get(forDomain: siteRating.url.host ?? "") else {
            return
        }
        DisplayableCertificateBuilder().build(usingTrust: serverTrust) { [weak self] displayable in
            self?.sections = displayable.toSections()
            DispatchQueue.main.async {
                self?.tableView.reloadData()
            }
        }
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
        if let header = tableView.tableHeaderView {
            let newSize = header.systemLayoutSizeFitting(UIView.layoutFittingCompressedSize)
            header.frame.size.height = newSize.height
            DispatchQueue.main.async {
                self.tableView.tableHeaderView = header
            }
        }
    }

}

extension PrivacyProtectionEncryptionDetailController: PrivacyProtectionInfoDisplaying {

    func using(siteRating: SiteRating, protectionStore: ContentBlockerProtectionStore) {
        self.siteRating = siteRating
    }

}

extension PrivacyProtectionEncryptionDetailController: UITableViewDelegate {

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        guard siteRating.https else { return nil }
        guard let header = tableView.dequeueReusableCell(withIdentifier: "Header") as? PrivacyProtectionEncryptionHeaderCell else {
            fatalError("Failed to dequeue cell as PrivacyProtectionEncryptionHeaderCell")
        }
        header.update(section: sections[section].name)
        return header
    }

}

extension PrivacyProtectionEncryptionDetailController: UITableViewDataSource {

    func numberOfSections(in tableView: UITableView) -> Int {
        return siteRating.https ? sections.count : 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return siteRating.https ? sections[section].rows.count : 1
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return siteRating.https ? sections[section].name : nil
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return siteRating.https ? cellForEncrypted(at: indexPath) : cellForUnencrypted()
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }

    private func cellForEncrypted(at indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as? PrivacyProtectionEncryptionDetailCell else {
            fatalError("Failed to dequeue cell as PrivacyProtectionEncryptionDetailCell")
        }
        cell.update(name: sections[indexPath.section].rows[indexPath.row].name, value: sections[indexPath.section].rows[indexPath.row].value)
        return cell
    }

    private func cellForUnencrypted() -> UITableViewCell {
        return tableView.dequeueReusableCell(withIdentifier: "Unencrypted")!
    }

}

fileprivate extension Data {

    func hexString() -> String {
        let bytes =  map { String(format: "%02hhx", $0) }
        return "\(bytes.count) bytes : \(bytes.joined(separator: " "))"
    }

}

class PrivacyProtectionEncryptionDetailCell: UITableViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var valueLabel: UILabel!

    func update(name: String, value: String) {
        nameLabel.text = name
        valueLabel.text = value
    }

}

class PrivacyProtectionEncryptionUnencrytedCell: UITableViewCell {

    @IBOutlet weak var detailLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        
        detailLabel.setAttributedTextString(UserText.ppEncryptionUnencryptedDetailInfo)
    }

}

class PrivacyProtectionEncryptionHeaderCell: UITableViewCell {

    @IBOutlet weak var sectionLabel: UILabel!

    func update(section: String) {
        sectionLabel.text = section
    }

}

extension DisplayableCertificate {

    func toSections() -> [PrivacyProtectionEncryptionDetailController.Section] {
        var sections = [PrivacyProtectionEncryptionDetailController.Section]()

        if isError {
            sections.append(PrivacyProtectionEncryptionDetailController.Section(name: UserText.ppEncryptionCertError, rows: []))
            return sections
        }

        sections.append(PrivacyProtectionEncryptionDetailController.Section(name: UserText.ppEncryptionSubjectName, rows: buildIdentitySection()))

        if let publicKey = publicKey {
            sections.append(PrivacyProtectionEncryptionDetailController.Section(name: UserText.ppEncryptionPublicKey, rows: publicKey.toRows()))
        }

        var issuer: DisplayableCertificate! = self.issuer
        while issuer != nil {
            sections.append(PrivacyProtectionEncryptionDetailController.Section(name: issuer.commonName ?? UserText.ppEncryptionIssuer,
                                                                                rows: issuer.buildIdentitySection()))

            if let issuerKey = issuer.publicKey {
                sections.append(PrivacyProtectionEncryptionDetailController.Section(name: UserText.ppEncryptionPublicKey, rows: issuerKey.toRows()))
            }

            issuer = issuer.issuer
        }

        return sections
    }

    private func buildIdentitySection() -> [PrivacyProtectionEncryptionDetailController.Row] {
        var rows = [PrivacyProtectionEncryptionDetailController.Row]()

        rows.append(PrivacyProtectionEncryptionDetailController.Row(name: UserText.ppEncryptionSummary, value: summary ?? "" ))
        rows.append(PrivacyProtectionEncryptionDetailController.Row(name: UserText.ppEncryptionCommonName, value: commonName ?? "" ))

        for email in emails ?? [] {
            rows.append(PrivacyProtectionEncryptionDetailController.Row(name: UserText.ppEncryptionEmail, value: email))
        }

        if let issuer = issuer {
            rows.append(PrivacyProtectionEncryptionDetailController.Row(name: UserText.ppEncryptionIssuer,
                                                                        value: issuer.commonName ?? UserText.ppEncryptionUnknown))
        }

        return rows
    }

}

extension DisplayableKey {

    func toRows() -> [PrivacyProtectionEncryptionDetailController.Row] {
        var rows = [PrivacyProtectionEncryptionDetailController.Row]()

        rows.append(PrivacyProtectionEncryptionDetailController.Row(name: UserText.ppEncryptionAlgorithm, value: type ?? ""))
        if let bitSize = bitSize {
            rows.append(PrivacyProtectionEncryptionDetailController.Row(name: UserText.ppEncryptionKeySize,
                                                                        value: UserText.ppEncryptionBits.format(arguments: bitSize)))
        }

        if let effectiveSize = effectiveSize {
            rows.append(PrivacyProtectionEncryptionDetailController.Row(name: UserText.ppEncryptionEffectiveSize,
                                                                        value: UserText.ppEncryptionBits.format(arguments: effectiveSize)))
        }

        let usage = [
            canDecrypt ? UserText.ppEncryptionUsageDecrypt : "",
            canDerive ? UserText.ppEncryptionUsageDerive : "",
            canEncrypt ? UserText.ppEncryptionUsageEncrypt : "",
            canSign ? UserText.ppEncryptionUsageSign : "",
            canUnwrap ? UserText.ppEncryptionUsageUnwrap : "",
            canVerify ? UserText.ppEncryptionUsageVerify : "",
            canWrap ? UserText.ppEncryptionUsageWrap : ""
            ].filter({ $0.count > 0 })
        if usage.count > 0 {
            rows.append(PrivacyProtectionEncryptionDetailController.Row(name: UserText.ppEncryptionUsage, value: usage.joined(separator: ", ")))
        }

        if let isPermanent = isPermanent {
            rows.append(PrivacyProtectionEncryptionDetailController.Row(name: UserText.ppEncryptionPermanent,
                                                                        value: isPermanent ? UserText.ppEncryptionYes :  UserText.ppEncryptionNo))
        }

        if let keyId = keyId {
            rows.append(PrivacyProtectionEncryptionDetailController.Row(name: UserText.ppEncryptionId, value: keyId.hexString()))
        }

        if let externalRepresentation = externalRepresentation {
            rows.append(PrivacyProtectionEncryptionDetailController.Row(name: UserText.ppEncryptionKey, value: externalRepresentation.hexString()))
        }

        return rows
    }

}
